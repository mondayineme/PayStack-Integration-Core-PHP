<?php

$con = new mysqli('localhost', 'root', '', 'paystack_payment');
if (!$con) {
    # code...
    echo "Not connected to database".mysqli_error($con);
}


?>