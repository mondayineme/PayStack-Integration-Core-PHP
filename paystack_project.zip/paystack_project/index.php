<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
     integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" 
    crossorigin="anonymous">
    <title>PayStack Payment Integration</title>
</head>
<body>
    
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card" style="width: 18rem; padding-bottom:40px; padding-top:40px;">
  <img src="img/iphone_12.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">IPhone 12 Pro</h5>
    <p class="card-text">This is a great deal never miss out buy today or regret tomorrow.
    Free chipping Feel included.
    </p>
    <a href="#" class="btn btn-dark">N80,000</a>
  </div>
</div>
</div>



<form id="paymentForm">
    <div style="padding-bottom:40px; padding-top:40px; color:white;">
        <button class="btn btn-dark">Fill Out The Form To Make Payment</button>
    </div>
  <div class="form-group">
    <label for="email">Email &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp;</label>
    <input type="email" id="email-address" required />
  </div>
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" />
  </div>
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" />
  </div>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()" style="padding-bottom:10px; margin-top:30px; padding-top:10px; background-color:black; color:white;"> Please Click Here To Make Payment </button>
  </div>
</form>
    </div>
</div>


<script src="https://js.paystack.co/v1/inline.js"></script> 

<br>
<script>
const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
  e.preventDefault();
  let handler = PaystackPop.setup({
    key: 'pk_test_7e747156ce1c24034445d6d71c4e9feb234fc0e9', // Replace with your public key
    email: document.getElementById("email-address").value,
    amount: 80000 * 100,
    firstname: document.getElementById("first-name").value,
    lastname: document.getElementById("last-name").value,
    ref: 'CLE_DEV'+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
        window.location = "http://localhost/paystack_project/index.php?transaction=cancel";
      alert('Transaction cancelled');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
      window.location = "http://localhost/paystack_project/verify_transaction.php?reference=" + response.reference;
    }
  });
  handler.openIframe();
}
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" 
integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" 
crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" 
integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" 
crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" 
integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>
</html>