<?php

$ref = $_GET['reference'];
if ($ref == "") {
    # code...
    header("Location:javascript://history.go(-1)");
}

?>

<?php

  $curl = curl_init();
  
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/transaction/verify/" . rawurlencode($ref),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer sk_test_ceba141e747f2014524bbbead8127ed5b62c7b4c",
      "Cache-Control: no-cache",
    ),
  ));
  
  $response = curl_exec($curl);
  $err = curl_error($curl);
  curl_close($curl);
  
  if ($err) {
    echo "cURL Error #:" . $err;
  } else {
    //echo $response;
    $result = json_decode($response);
  }

  if ($result->data->status == "success") {
    $status = $result->data->status;
    $reference = $result->data->reference;
    $lname = $result->data->customer->last_name;
    $fname = $result->data->customer->first_name;
    $full_name = $lname.' '.$fname;
    $cust_email = $result->data->customer->email;
    date_default_timezone_set('Africa/Lagos');
    $date_time = date('m/d/Y h:i:s a', time());

    include('database/m_db.php');
    $stmt = $con->prepare("INSERT INTO customer_details(status, reference, full_name, date_purchased, email) VALUES(?,?,?,?,?)");
    $stmt->bind_param("sssss", $status, $reference, $full_name, $date_time, $cust_email);
    $stmt->execute();
    if (!$stmt) {
        # code...
        echo "Server error".mysqli_error($con);
    }else{
        header("Location: success.php?status=success");
        exit;
    }
    $stmt->close();
    $con->close();

  }else{
      header("Location: error.html");
      exit;
  }
?>